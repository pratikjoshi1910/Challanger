package com.challanger.client.constants;

public class MessageConstants {
	
	public static String CREDENTIALS_MISSING = "UserName and/or Password is missing please enter the same.";

}
