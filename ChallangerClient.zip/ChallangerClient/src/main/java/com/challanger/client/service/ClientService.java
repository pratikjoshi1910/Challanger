package com.challanger.client.service;

public interface ClientService {

	
	public String loginValidatorAndEncryptor (String message);
}
