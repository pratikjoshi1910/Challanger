package com.challanger.client.service;

public interface InputAnalyzerService {

	public Object analyzeInput(Object object);

}
