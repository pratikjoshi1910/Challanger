package com.challanger.client.validator;

/**
 * @author pratik
 * 
 *         this class will be used for different sort of validations required at
 *         different stage of application life cycle.
 */
public class ValidatorImpl implements Validator {

	/*
	 * this method will be used for validation of the user login credentials
	 * 
	 */
	@Override
	public Boolean loginValidator(String tosend) {
		@SuppressWarnings("resource")
		String[] credentials = tosend.split(":");
		if (credentials.length < 2) {
			return false;
		}
		String userName = credentials[0];
		String passWord = credentials[1];
		if (!isNullOrEmpty(userName) && !isNullOrEmpty(passWord)) {

			return true;
		} else {
			return false;
		}
	}

	private boolean isNullOrEmpty(String str) {
		if (str != null && !str.isEmpty())
			return false;
		return true;
	}
}
