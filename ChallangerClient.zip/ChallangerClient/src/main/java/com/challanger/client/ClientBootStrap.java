package com.challanger.client;
import java.io.IOException;

public class ClientBootStrap {

	public static void main(String[] args) throws IOException, InterruptedException  
	 {
		ClientTemplate.clientStarterTemplate();
	 }
}
