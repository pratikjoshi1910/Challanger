package com.challanger.client.service;

import java.util.Base64;
import java.util.Scanner;

import com.challanger.client.constants.MessageConstants;
import com.challanger.client.validator.Validator;
import com.challanger.client.validator.ValidatorImpl;



public class ClientServiceImpl implements ClientService {

	@Override
	public String loginValidatorAndEncryptor(String message) {

		Validator validator = new ValidatorImpl();
		@SuppressWarnings("resource")
		Scanner scn = new Scanner(System.in);

		Boolean result = false;
		while (!result) {
			result = validator.loginValidator(message);
			if (result) {
				String[] credentials = message.split(":");
				String userName = credentials[0];
				String passWord = credentials[1];
				String password = Base64.getEncoder().encodeToString(passWord.getBytes());
				message = userName + ":" + password;
				return message;
			} else {
				System.out.println(MessageConstants.CREDENTIALS_MISSING);
				message = scn.nextLine();
				validator.loginValidator(message);
			}
		}
		return message;
	}

}
