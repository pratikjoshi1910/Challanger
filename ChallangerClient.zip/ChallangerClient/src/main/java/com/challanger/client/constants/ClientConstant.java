package com.challanger.client.constants;

public class ClientConstant {
	
	public static String SERVER_URL = "localhost";
	
	public static String CONFIG_PROPS = "Config.properties";
	
	public static String REMOTE_DOWN = "It seems that remote server is down retrying after 10 seconds";
	
	public static String ERROR_DATA_RETRIVAL = "Something wrong happen while retriving data.";

}
