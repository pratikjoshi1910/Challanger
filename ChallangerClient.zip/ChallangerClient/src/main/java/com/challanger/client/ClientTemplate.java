package com.challanger.client;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.util.Properties;
import java.util.Scanner;

import com.challanger.client.constants.ClientConstant;
import com.challanger.client.service.ClientService;
import com.challanger.client.service.ClientServiceImpl;
import com.challanger.client.service.InputAnalyzerService;
import com.challanger.client.service.InputAnalyzerServiceImpl;
import com.challanger.server.stub.Messanger;


//Client class 
public class ClientTemplate {

	public static final void clientStarterTemplate() throws IOException, InterruptedException {
		startClient();
	}

	private static void startClient() throws IOException, InterruptedException {
		try {
			Scanner scanner = new Scanner(System.in);
			Properties prop = new Properties();
			InputStream input = ClientTemplate.class.getClassLoader().getResourceAsStream(ClientConstant.CONFIG_PROPS);
			// load a properties file
			prop.load(input);
			// getting server ip
			InetAddress ip = InetAddress.getByName(prop.getProperty("server"));
			// establish the connection with server port 5057
			Socket socket = null;
			try {
				socket = new Socket(ip, 5058);
			} catch (Exception e) {
				System.out.println(ClientConstant.REMOTE_DOWN);
				Thread.sleep(10000);
				startClient();
			}

			// obtaining input and out streams
			DataInputStream dataInputStream = new DataInputStream(socket.getInputStream());
			DataOutputStream dataOutputStream = new DataOutputStream(socket.getOutputStream());
			ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(socket.getOutputStream());

			while (true) {
				Messanger received = (Messanger) objectInputStream.readObject();
				String tosend = "continue";
				if (received.getIsStartUp()) {
					System.out.println(received.getMessage());
					tosend = scanner.nextLine();
					ClientService clientService = new ClientServiceImpl();
					received.setMessage(clientService.loginValidatorAndEncryptor(tosend));
					objectOutputStream.writeObject(received);
				} else {
					InputAnalyzerService analyZerService = new InputAnalyzerServiceImpl();
					received = (Messanger) analyZerService.analyzeInput(received);
					objectOutputStream.writeObject(received);

				}

				// If client sends exit,close this connection
				// and then break from the while loop
				if (tosend.equals("Exit")) {
					System.out.println("Closing this connection : " + socket);
					socket.close();
					System.out.println("Connection closed");
					break;
				}

			}

			// closing resources
			scanner.close();
			dataInputStream.close();
			dataOutputStream.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println(ClientConstant.ERROR_DATA_RETRIVAL);
			Thread.sleep(100);
			startClient();
		}
	}
}
