package com.challanger.client.service;

import java.util.Scanner;

import com.challanger.server.stub.Command;
import com.challanger.server.stub.Messanger;
import com.challanger.server.stub.QuestionPayLoad;

public class InputAnalyzerServiceImpl implements InputAnalyzerService {

	@Override
	public Object analyzeInput(Object object) {
		// check the flow for the Messanger object
		if (object instanceof Messanger) {
			@SuppressWarnings("resource")
			Scanner scanner = new Scanner(System.in);
			Object toSend = null;
			Messanger messanger = (Messanger) object;
			if (null == messanger.getPayLoad()) {
				System.out.println(messanger.getMessage());
				toSend = scanner.nextLine();
				messanger.setMessage((String) toSend);
				return messanger;
			} else {
				QuestionPayLoad questionPayLoad = (QuestionPayLoad) messanger.getPayLoad();
				System.out.println("Please answer blow question with proper answerId." + "\n");
				System.out.println("Question ::" + questionPayLoad.getQuestion() + "\n");
				System.out.println("option ::" + "\n");
				System.out.println(questionPayLoad.getOptions() + "\n");
				toSend = scanner.nextLine();
				questionPayLoad.setAnswer(Integer.parseInt((String)toSend) );
				//messanger.setPayLoad("Hello");
				return messanger;

			}
		}
		// check the flow for the command object
		else if (object instanceof Command) {

		}
		return object;

	}

}
