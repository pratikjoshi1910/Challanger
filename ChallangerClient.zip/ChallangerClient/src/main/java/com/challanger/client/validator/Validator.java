package com.challanger.client.validator;

public interface Validator {
	
	public Boolean loginValidator(String credentials);

}
