package com.challanger.server.validator;

import java.util.ArrayList;
import java.util.stream.Collectors;

import com.challanger.server.constants.ServerConstant;
import com.challanger.server.dto.FunctionalValidator;
import com.challanger.server.stub.Messanger;
import com.challanger.server.stub.Skill;
import com.challanger.server.stub.User;

public class ThirdStageValidatorService implements ValidatorService {

	@Override
	public Boolean validate(Messanger messanger) {
		// TODO Auto-generated method stub
		boolean result = false;
		String message = messanger.getMessage();
		if (isNullOrEmpty(message)) {
			return false;
		} else if (message.contains(",")) {
			String[] courses = message.split(",");
			for (String id : courses) {
				try {
					Integer.parseInt(id);
				} catch (NumberFormatException e) {
					return false;
				}

			}
			return true;
		} else {
			try {
				Integer.parseInt(message);
				return true;
			} catch (NumberFormatException e) {

			}
		}
		return result;

	}

	@Override
	public FunctionalValidator functionalValidation(Messanger messanger) {
		FunctionalValidator validator = CheckMiniMumPrice(messanger);
		if (validator.getResult()) {
			validator = checkTotalPrice(messanger);
			return validator;
		}

		return validator;

	}

	private FunctionalValidator checkTotalPrice(Messanger messanger) {
		//Integer totalCost = 0;
		FunctionalValidator validator = new FunctionalValidator();
		String[] idString = messanger.getMessage().split(",");
		ArrayList<Integer> ids = new ArrayList<>();
		for(String id:idString)
		{
			ids.add(Integer.parseInt(id));
		}
		User user = ServerConstant.userMap.get(messanger.getMetaData().getUserName());
		if (null != user.getCourses())
		{
			ids.removeAll(user.getCourses().stream().map(Skill::getId).collect(Collectors.toList()));
		}
		Integer totalCost = ServerConstant.skillList.stream().filter(x -> ids.contains(x.getId()))
				.mapToInt(x -> x.getPrice()).sum();
		Long credit = ServerConstant.userMap.get(messanger.getMetaData().getUserName()).getCredits();
	
		if (credit > totalCost.longValue()) {
			validator.setResult(true);
			Long expectedCredit = credit - totalCost.longValue();
			validator.getSearchings().put("credit",expectedCredit);
			validator.getSearchings().put("courseIds", ids);
			return validator;
		} else {
			validator.setResult(false);
			validator.setMessage("Low credit to buy a course.");
			return validator;

		}
	}

	private FunctionalValidator CheckMiniMumPrice(Messanger messanger) {
		FunctionalValidator validator = new FunctionalValidator();
		User user = ServerConstant.userMap.get(messanger.getMetaData().getUserName());
		if (user.getCredits() < ServerConstant.MINIMUM_COURSE_PRICE) {
			validator.setResult(false);
			validator.setMessage("You are to purchase course due to low balances.");

		} else {
			validator.setResult(true);

		}
		return validator;

	}

	private boolean isNullOrEmpty(String str) {
		if (str != null && !str.isEmpty())
			return false;
		return true;
	}

}
