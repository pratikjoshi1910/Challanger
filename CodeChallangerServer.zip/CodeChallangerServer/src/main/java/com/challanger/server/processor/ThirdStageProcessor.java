package com.challanger.server.processor;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.challanger.server.constants.MessageConstants;
import com.challanger.server.constants.RoutingMap;
import com.challanger.server.constants.ServerConstant;
import com.challanger.server.dto.FunctionalValidator;
import com.challanger.server.service.CourseService;
import com.challanger.server.service.CourseServiceImpl;
import com.challanger.server.service.UserService;
import com.challanger.server.service.UserServiceImpl;
import com.challanger.server.stage.factory.StageProcessorFactory;
import com.challanger.server.stub.Messanger;
import com.challanger.server.stub.Skill;
import com.challanger.server.stub.Stage;
import com.challanger.server.stub.User;
import com.challanger.server.validator.ThirdStageValidatorService;
import com.challanger.server.validator.ValidatorService;

public class ThirdStageProcessor implements StageProcessor {
	@Override
	public Messanger processInput(Messanger messanger) {
		System.out.println("inside third stage processor");
		messanger.setState(ServerConstant.stateMap.get(3));
		ValidatorService validatorService = new ThirdStageValidatorService();
		Boolean isValid = validatorService.validate(messanger);
		if (isValid) {
			FunctionalValidator validator = validatorService.functionalValidation(messanger);
			if (validator.getResult()) {
			//	ArrayList<Integer> courseIds = (ArrayList<Integer>) validator.getSearchings().get("courseIds");
				@SuppressWarnings("unchecked")
				ArrayList<Integer> courseIds =  (ArrayList<Integer>) validator.getSearchings().get("courseIds");
			//	courseIds.add(1);
				/*for (String courseId : ids) {
					courseIds.add(Integer.parseInt(courseId));
				}*/
				CourseService courseService = new CourseServiceImpl();
				Set<Skill> requestedCourses = courseService.getCourseById(courseIds);
				User user = ServerConstant.userMap.get(messanger.getMetaData().getUserName());
				Set<Skill> userCourses = user.getCourses();
				if (null == userCourses) {
					user.setCourses(requestedCourses);

					user.setCredits((Long) validator.getSearchings().get("credit"));

				} else {
					user.getCourses().addAll(requestedCourses);
					user.setCredits((Long) validator.getSearchings().get("credit"));

				}
				// call for serialze data to file is yet left for implementation
				// so that we can get
				// updated information of user on next time start up;

			} else {
				messanger.setMessage(validator.getMessage());
				return messanger;
			}

		} else {
			messanger.setMessage("please enter valid input.");
			return messanger;
		}
		Integer nextStageId = (Integer) RoutingMap.routingMap.get("3").get("Success");
		Stage nextStage = ServerConstant.stateMap.get(nextStageId);
		StageProcessor stageProcessor = StageProcessorFactory.getProcessor(nextStageId);
		messanger.setState(nextStage);
		String stageMessage = (String) stageProcessor.getStageMessage(messanger);
		messanger.setMessage(MessageConstants.COURSE_SUCCESS_MESSAGE + "\n" + stageMessage);
		return messanger;

	}

	@Override
	public Object getStageMessage(Messanger messanger) {

		String userName = messanger.getMetaData().getUserName();
		// User user = ServerConstant.userMap.get(userName);
		UserService userService = new UserServiceImpl();
		Set<Skill> userCourses = userService.getUseCourses(userName);
		List<Skill> availableCourses = userService.getUserAvailableCourses(userName);
		Long userCredit = userService.getUserCredit(userName);
		String creditMessage = "Your available credit is ::" + userCredit;
		String instructionMessage = "Please select id of the courses to purchase seprated by commas.";
		StringBuffer optedCourses = new StringBuffer();
		StringBuffer availableCourse = new StringBuffer();
		optedCourses.append("Courses you opted are ::" + "\n");

		availableCourse.append("Courses available to you are ::" + "\n");
		if (null != userCourses) {
			for (Skill skill : userCourses) {

				optedCourses.append("id:" + ":" + skill.getId() + " " + "name:" + ":" + skill.getName() + " "
						+ "price::" + skill.getPrice());
				optedCourses.append("\n");

			}
		}
		if (null != availableCourse) {
			for (Skill skill : availableCourses) {

				availableCourse.append("id:" + ":" + skill.getId() + " " + "name:" + ":" + skill.getName() + " "
						+ "price::" + skill.getPrice());
				availableCourse.append("\n");

			}
		}
		String message = creditMessage + "\n" + availableCourse + "\n" + optedCourses + "\n" + instructionMessage;
		return message;
	}

}
