package com.challanger.server.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.challanger.server.constants.ServerConstant;
import com.challanger.server.stub.Skill;

/**
 * @author pratik
 *
 */
public class CourseServiceImpl implements CourseService{

	@Override
	public List<Skill> getAllCourses() {
		// 
		return ServerConstant.skillList;
	}

	@Override
	public Set<Skill> getCourseById(ArrayList<Integer> skillIds) {
		// 
		return (Set<Skill>) ServerConstant.skillList.stream().filter(x ->skillIds.contains(x.getId())).collect(Collectors.toSet());
	}



}
