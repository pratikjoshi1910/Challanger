package com.challanger.server.stub;

import java.io.Serializable;

public class MetaData implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer state;

	private String userName;

	private String ipAddress;

	/**
	 * @return the state
	 */
	public Integer getState() {
		return state;
	}

	/**
	 * @param state
	 *            the state to set
	 */
	public MetaData setState(Integer state) {
		this.state = state;
		return this;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param userName
	 *            the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the ipAddress
	 */
	public String getIpAddress() {
		return ipAddress;
	}

	/**
	 * @param ipAddress
	 *            the ipAddress to set
	 */
	public MetaData setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
		return this;
	}

	public MetaData metaDataBuilder() {
		return this;

	}

}
