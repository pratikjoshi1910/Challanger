package com.challanger.server.auth;

import com.challanger.server.stub.Messanger;

/**
 * @author pratik
 * 
 *interface for authentication.
 */
public interface Authntication {
	
	public Messanger authenticate (String credentials);


}
