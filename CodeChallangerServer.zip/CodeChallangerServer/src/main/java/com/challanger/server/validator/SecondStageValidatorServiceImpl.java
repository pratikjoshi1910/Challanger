package com.challanger.server.validator;

import com.challanger.server.dto.FunctionalValidator;
import com.challanger.server.stub.Messanger;

public class SecondStageValidatorServiceImpl implements ValidatorService {

	@Override
	public Boolean validate(Messanger messanger) {
		String message = messanger.getMessage();
		if (null == message) {
			return false;

		}

		if (message.isEmpty()) {
			return false;
		} else {
			try {
				Integer.parseInt(message);
				return true;
			} catch (NumberFormatException e) {

			}
		}
		return false;
	}

	@Override
	public FunctionalValidator functionalValidation(Messanger messanger) {
		// TODO Auto-generated method stub
		FunctionalValidator validator = new FunctionalValidator();
		validator.setResult(true);
		return validator;
	}

}
