package com.challanger.server.validator;

import com.challanger.server.dto.FunctionalValidator;
import com.challanger.server.stub.Messanger;

/**
 * @author pratik
 *
 *         validator service provides the functional as well as the input level
 *         validation for the message at all the level.
 */
public interface ValidatorService {

	public Boolean validate(Messanger messanger);

	public FunctionalValidator functionalValidation(Messanger messanger);

}
