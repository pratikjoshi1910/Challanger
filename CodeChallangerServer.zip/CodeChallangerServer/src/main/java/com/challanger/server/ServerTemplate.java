package com.challanger.server;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import com.challanger.server.constants.ServerConstant;
import com.challanger.server.handler.ClientHandler;

/**
 * @author pratik
 *
 *         This class work as a standard application template it is currently it
 *         is responsible for loding configurations and starting the server
 *         however in future many more standard methods can be added here which
 *         can eventually decide the application life cycle.
 *
 *
 */
public class ServerTemplate {

	private static final Logger LOGGER = Logger.getLogger(ServerTemplate.class.getName());

	/**
	 * @throws IOException
	 * @throws ClassNotFoundException
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 *             this method is the template to bootstrap server class and its
	 *             methods are final so no other class can make any change it to
	 *             it.
	 */
	public static final void serverStarterTemplate() throws IOException, ClassNotFoundException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		loadConfig();
		startServer();
	}

	/**
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws NoSuchMethodException
	 * @throws SecurityException
	 * @throws IllegalAccessException
	 * @throws IllegalArgumentException
	 * @throws InvocationTargetException
	 *             this method will scan for all the class with @config
	 *             annotations and load the data from their config method in a
	 *             way it will help to load config data on startup.
	 */
	private static void loadConfig() throws ClassNotFoundException, IOException, NoSuchMethodException,
			SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {

		LOGGER.info("load config method of template class is calling the other config methods");
		// get all class with @config annotation.
		ArrayList<Class<?>> classes = new ArrayList<Class<?>>();
		ClassLoader cld = Thread.currentThread().getContextClassLoader();
		if (cld == null) {
			throw new ClassNotFoundException("Can't get class loader.");
		}
		String path = ServerConstant.CONFIG_PCKG.replace('.', '/');

		URL[] urls = ((URLClassLoader) cld).getURLs();
		String uri = urls[0].getFile();
		String jarPath = uri.toString();
		if (jarPath.contains(".jar")) {
			LOGGER.info("load config method of template class is calling the other config methods");

			classes.addAll(getClassesInSamePackageFromJars(jarPath));
		} else {
			Enumeration<URL> resources = cld.getResources(path);
			List<File> dirs = new ArrayList<File>();
			while (resources.hasMoreElements()) {
				URL resource = (URL) resources.nextElement();
				dirs.add(new File(resource.getFile()));
				for (File directory : dirs) {

					classes.addAll(
							findClasses(directory, ServerConstant.CONFIG_PCKG, ServerConstant.CONFIG_ANNOTATION));

				}

			}
		}

		// call the load config method from the config class
		// which eventually call the internal methods of the
		// configuration class.

		for (Class<?> clazz : classes) {
			clazz.getMethod("loadConfig", null).invoke(null, null);
		}
		LOGGER.info("Application configuration loaded successfully.");

	}

	private static List<Class<?>> findClasses(File directory, String packageName, String annotation)
			throws ClassNotFoundException {
		List<Class<?>> classes = new ArrayList<Class<?>>();
		if (!directory.exists()) {
			System.out.println("directory does not exist" + directory.getAbsolutePath());
			return classes;
		}
		File[] files = directory.listFiles();
		for (File file : files) {
			if (file.isDirectory()) {
				assert !file.getName().contains(".");
				classes.addAll(findClasses(file, packageName + "." + file.getName(), annotation));
			} else if (file.getName().endsWith(".class")) {
				Class<?> clazz = Class
						.forName(packageName + '.' + file.getName().substring(0, file.getName().length() - 6));
				if (null != clazz.getAnnotations()) {
					List<String> annotationList = Arrays.asList(clazz.getAnnotations()).stream()
							.map(x -> x.annotationType().getName()).collect(Collectors.toList());
					if (annotationList.contains(annotation)) {
						classes.add(clazz);
					}
				}
			}
		}
		return classes;
	}

	/**
	 * @throws IOException
	 *             this method will start the server and open the socket
	 *             connection to desired port.
	 */
	private static void startServer() throws IOException {
		@SuppressWarnings("resource")
		ServerSocket ss = new ServerSocket(5058);
		LOGGER.log(Level.FINE, "Starting the application server on port::" + 5058);

		// socket object to receive incoming client requests
		while (true) {
			Socket s = null;
			try {
				s = ss.accept();
				LOGGER.info("Client is connected successfully  on socket::" + s);
				// obtaining input and out streams
				DataInputStream dis = new DataInputStream(s.getInputStream());
				DataOutputStream dos = new DataOutputStream(s.getOutputStream());
				LOGGER.info("Assigning a new thread to new request::");
				// create a new thread object
				ClientHandler clientHandler = new ClientHandler(s, dis, dos);
				// Invoking the start() method.
				clientHandler.start();
			} catch (Exception e) {
				LOGGER.log(Level.SEVERE, "Exception occured while connecting the server" + e.getMessage());

				s.close();
			}
		}
	}

	private static List<Class<?>> getClassesInSamePackageFromJars(String jarPath) {
		LOGGER.info("Scanning for the configuration classes from the path of jar.");

		JarFile jarFile = null;
		List<Class<?>> result = new ArrayList<>();
		try {
			jarFile = new JarFile(jarPath);
			// ClassLoader cld = Thread.currentThread().getContextClassLoader();
			Enumeration<JarEntry> en = jarFile.entries();
			while (en.hasMoreElements()) {
				JarEntry entry = en.nextElement();
				String entryName = entry.getName();
				String packageName = ServerConstant.CONFIG_PCKG.replace('.', '/');
				if (entryName != null && entryName.endsWith(".class") && entryName.startsWith(packageName)) {
					try {
						System.out.println(entryName);
						Class<?> entryClass = Class
								.forName(entryName.substring(0, entryName.length() - 6).replace('/', '.'));
						if (entryClass != null) {
							System.out.println(entryClass);
							result.add(entryClass);
							// entryClass.getMethod("loadConfig",
							// null).invoke(null, null);
						}

					} catch (Throwable e) {
						// do nothing, just continue processing classes
						LOGGER.info("System got exception :: " + e.getMessage()
								+ "However other configuration flow is still going on.");

					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			// result.addAll(Arrays.asList(classes));
		} finally {
			try {
				if (jarFile != null)
					LOGGER.info("Closing the jar file connections.");

				jarFile.close();
			} catch (Exception e) {
			}
		}
		return result;
	}

}
