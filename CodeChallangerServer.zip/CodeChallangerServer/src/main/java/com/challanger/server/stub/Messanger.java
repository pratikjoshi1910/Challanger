package com.challanger.server.stub;

import java.io.Serializable;

public class Messanger implements Serializable {

	private static final long serialVersionUID = 1L;

	private String message;

	private Stage state;

	private MetaData metaData;
	
	private Boolean isStartUp =false;
	
	private Object payLoad;

	/**
	 * @return the payLoad
	 */
	public Object getPayLoad() {
		return payLoad;
	}

	/**
	 * @param payLoad the payLoad to set
	 */
	public void setPayLoad(Object payLoad) {
		this.payLoad = payLoad;
	}

	/**
	 * @return the isStartUp
	 */
	public Boolean getIsStartUp() {
		return isStartUp;
	}

	/**
	 * @param isStartUp the isStartUp to set
	 */
	public void setIsStartUp(Boolean isStartUp) {
		this.isStartUp = isStartUp;
	}

	public Messanger() {

	}

	/**
	 * @return the metaData
	 */
	public MetaData getMetaData() {
		return metaData;
	}

	/**
	 * @param metaData
	 *            the metaData to set
	 */
	public void setMetaData(MetaData metaData) {
		this.metaData = metaData;
	}

	

	public Messanger(String message) {
		// TODO Auto-generated constructor stub
		this.message=message;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message
	 *            the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @return the state
	 */
	public Stage getState() {
		return state;
	}

	/**
	 * @param state
	 *            the state to set
	 */
	public void setState(Stage state) {
		this.state = state;
	}

}
