package com.challanger.server.analyzer;

import com.challanger.server.stub.Messanger;

/**
 * @author pratik
 *
 *this interface is the first logical entry point of the message in the 
 *system object will pass through the various implementation of 
 *of this interface and analyzed based on several application
 *logic.

 */
public interface InputAnalyzer {
	
	Messanger analyzeInput(Object receivedMessage);

}
