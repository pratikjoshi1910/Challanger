package com.challanger.server.processor;

import com.challanger.server.stub.Messanger;

public interface StageProcessor {

	Object getStageMessage(Messanger messanger);
	
	public Messanger processInput(Messanger messanger); 

}
