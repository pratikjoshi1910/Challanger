package com.challanger.server.metadatapreparator;

import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.List;
import java.util.jar.JarEntry;
import java.util.jar.JarFile;
import java.util.stream.Collectors;

import com.challanger.server.constants.ServerConstant;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassLoader cld = Thread.currentThread().getContextClassLoader();
		URL[] urls = ((URLClassLoader) cld).getURLs();
		String uri = urls[0].getFile();
		String s = uri.toString();
		System.out.println("uri is " + s);
		// String s = "E://ChallangerServer-1.0-SNAPSHOT.jar";
		  getClassesInSamePackageFromJars(s);
	}
	
	 private static List<Class<?>> getClassesInSamePackageFromJars( String jarPath) {
	      JarFile jarFile = null; 
	      List<Class<?>> result = new ArrayList<>();
	      try {
	        jarFile = new JarFile(jarPath);
	        //ClassLoader cld = Thread.currentThread().getContextClassLoader();
	        Enumeration<JarEntry> en = jarFile.entries();
	        while(en.hasMoreElements()) {
	          JarEntry entry = en.nextElement();
	          String entryName = entry.getName();        
	            String packageName =ServerConstant.CONFIG_PCKG.replace('.', '/');
	            if(entryName != null && entryName.endsWith(".class") && entryName.startsWith(packageName)) {              
	              try {
	            	  System.out.println(entryName);
	                Class<?> entryClass = Class.forName(entryName.substring(0,entryName.length()-6).replace('/', '.'));
	                if(entryClass != null)
	                {
	                	System.out.println(entryClass);
	                  result.add(entryClass);    
	                  entryClass.getMethod("loadConfig", null).invoke(null, null);
	                }

	              } catch (Throwable e) {
	              // do nothing, just continue processing classes
	            }
	            }
	          }          
	        
	      } catch (Exception e) {
	    	  e.printStackTrace();
	       // result.addAll(Arrays.asList(classes));
	      } finally {
	        try {
	          if(jarFile != null)
	            jarFile.close();
	        } catch (Exception e) {      
	      }
	      }
	      return result;
	    }
}
