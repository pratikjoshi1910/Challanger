package com.challanger.server.processor;

import com.challanger.server.constants.MessageConstants;
import com.challanger.server.constants.RoutingMap;
import com.challanger.server.constants.ServerConstant;
import com.challanger.server.dto.ErrorObject;
import com.challanger.server.stage.factory.StageProcessorFactory;
import com.challanger.server.stub.Messanger;
import com.challanger.server.stub.Stage;
import com.challanger.server.validator.SecondStageValidatorServiceImpl;
import com.challanger.server.validator.ValidatorService;

public class SecondStageProcessor implements StageProcessor {

	@Override
	public Messanger processInput(Messanger messanger) {
		ValidatorService validatorService = new SecondStageValidatorServiceImpl();
		Boolean isValid = validatorService.validate(messanger);
		if (isValid) {
			String input = messanger.getMessage();
			Stage nextStage = getNextStage(input);
			StageProcessor nextStageProcessor = StageProcessorFactory.getProcessor(nextStage.getId());
			Object nextStageDetail = nextStageProcessor.getStageMessage(messanger);
			if (nextStageDetail instanceof ErrorObject) {
				ErrorObject error = (ErrorObject) nextStageDetail;
				messanger.setMessage(error.getErrorMessage() + "\n" + StageProcessorFactory.getProcessor(2).getStageMessage(messanger));
			}

			else if (nextStageDetail instanceof String) {
				messanger.setMessage((String) nextStageDetail);
				messanger.setState(nextStage);

			} else {
				messanger.setPayLoad(nextStageDetail);
				messanger.setState(nextStage);

			}
		} else {
			messanger.setMessage("please enter valid input.");
		}
		return messanger;
	}

	private Stage getNextStage(String input) {
		// TODO Auto-generated method stub
		Integer stageId = (Integer) RoutingMap.routingMap.get("2").get(input);
		return ServerConstant.stateMap.get(stageId);
	}

	@Override
	public Object getStageMessage(Messanger messanger) {
		// TODO Auto-generated method stub
		return MessageConstants.SECOND_STAGE_WELCOME_MESSAGE;
	}

}
