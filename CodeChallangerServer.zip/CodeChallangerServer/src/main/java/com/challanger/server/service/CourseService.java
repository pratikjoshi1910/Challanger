package com.challanger.server.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import com.challanger.server.stub.Skill;

/**
 * @author pratik
 *
 *         provides basic course level operations required by application.
 */
public interface CourseService {

	List<Skill> getAllCourses();

	Set<Skill> getCourseById(ArrayList<Integer> skillIds);

}
