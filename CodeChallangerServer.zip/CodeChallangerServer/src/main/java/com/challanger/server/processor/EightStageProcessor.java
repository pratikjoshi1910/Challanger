package com.challanger.server.processor;

import java.util.logging.Logger;

import com.challanger.server.constants.RoutingMap;
import com.challanger.server.constants.ServerConstant;
import com.challanger.server.stage.factory.StageProcessorFactory;
import com.challanger.server.stub.Messanger;
import com.challanger.server.stub.Stage;
import com.challanger.server.stub.User;

public class EightStageProcessor implements StageProcessor {
	Logger logger = Logger.getLogger(EightStageProcessor.class.getName());

	private static String STAGE_ID = "8";

	@Override
	public Object getStageMessage(Messanger messanger) {
		// TODO Auto-generated method stub
		logger.info("fetching the message of stage eight for :: " + messanger.getMetaData().getUserName());
		String userName = messanger.getMetaData().getUserName();
		User user = ServerConstant.userMap.get(userName);
		Long credit = user.getCredits();
		String welcomeMessage = ServerConstant.CREDIT_SCORE_PREFIX + credit;
		return welcomeMessage;
	}

	@Override
	public Messanger processInput(Messanger messanger) {
		logger.info("Processing the eight stage message for :: " + messanger.getMetaData().getUserName());

		Integer nextStageId = (Integer) RoutingMap.routingMap.get(STAGE_ID).get(ServerConstant.SUCCESS_FLAG);
		Stage nextStage = ServerConstant.stateMap.get(nextStageId);
		StageProcessor stageProcessor = StageProcessorFactory.getProcessor(nextStageId);
		messanger.setState(nextStage);
		String stageMessage = (String) stageProcessor.getStageMessage(messanger);
		messanger.setMessage(stageMessage);
		logger.info("Successfully processed eigth stage  message for  :: " + messanger.getMetaData().getUserName());

		return messanger;
	}

}
