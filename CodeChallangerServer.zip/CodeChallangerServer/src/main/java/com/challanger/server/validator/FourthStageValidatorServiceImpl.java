package com.challanger.server.validator;

import java.util.List;
import java.util.stream.Collectors;

import com.challanger.server.constants.ServerConstant;
import com.challanger.server.dto.FunctionalValidator;
import com.challanger.server.stub.Messanger;
import com.challanger.server.stub.Skill;
import com.challanger.server.stub.User;

public class FourthStageValidatorServiceImpl implements ValidatorService {

	@Override
	public Boolean validate(Messanger messanger) {

		String message = messanger.getMessage();
		if (null == message) {
			return false;

		}

		if (message.isEmpty()) {
			return false;
		} else {
			try {
				Integer.parseInt(message);
				return true;
			} catch (NumberFormatException e) {

			}
		}
		return false;

	}

	@Override
	public FunctionalValidator functionalValidation(Messanger messanger) {
		// TODO Auto-generated method stub
		FunctionalValidator functionalValidator = new FunctionalValidator();
		User user = ServerConstant.userMap.get(messanger.getMetaData().getUserName());
		if (null != user.getCourses()) {
			List<Integer> skillIds = user.getCourses().stream().map(Skill::getId).collect(Collectors.toList());
			boolean access = skillIds.contains(Integer.parseInt(messanger.getMessage()));
			if (!access) {
				functionalValidator.setResult(false);
				functionalValidator
						.setMessage("You do not have access for this course please buy the same and try to read it.");
				return functionalValidator;
			}
		}
		functionalValidator.setResult(true);
		return functionalValidator;
	}

}
