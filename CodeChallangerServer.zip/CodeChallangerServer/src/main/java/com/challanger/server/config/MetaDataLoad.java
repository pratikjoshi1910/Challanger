package com.challanger.server.config;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.challanger.server.annotation.Config;
import com.challanger.server.constants.ServerConstant;
import com.challanger.server.exception.CustomException;
import com.challanger.server.stub.Question;
import com.challanger.server.stub.Quiz;
import com.challanger.server.stub.Role;
import com.challanger.server.stub.Skill;
import com.challanger.server.stub.Stage;
import com.challanger.server.stub.User;

/**
 * @author pratik
 *
 *
 *         class is responsible for loading metada of the system on the
 *         configuration life cycle stage of the system.
 */
@Config
public class MetaDataLoad {

	/**
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws CustomException
	 * 
	 * 
	 */

	static Logger logger = Logger.getLogger(MetaDataLoad.class.getName());

	public static void loadConfig() throws ClassNotFoundException, IOException, CustomException {
		logger.log(Level.FINEST, "call for the template loading method.");
		loadEntity();
	}

	private static void loadEntity() throws IOException, ClassNotFoundException, CustomException {

		try {
			ClassLoader cld = Thread.currentThread().getContextClassLoader();
			logger.log(Level.FINEST, "loding the user data into the system.");

			BufferedInputStream bufferedInputStream = new BufferedInputStream(
					cld.getResourceAsStream(ServerConstant.USER_DATA_FILE));
			ObjectInputStream objectInputStream = new ObjectInputStream(bufferedInputStream);
			ServerConstant.userList = (CopyOnWriteArrayList<User>) objectInputStream.readObject();
			objectInputStream.close();
			logger.log(Level.FINEST, "user data loaded successfully.");

			// FileInputStream skillInputStream = new
			// FileInputStream("src//resources//skill.ser");
			logger.log(Level.FINEST, "loding the skill data into the system.");

			BufferedInputStream skillInputStream = new BufferedInputStream(
					cld.getResourceAsStream(ServerConstant.SKILL_DATA_FILE));

			BufferedInputStream skillBufferedInputStream = new BufferedInputStream(skillInputStream);
			ObjectInputStream skillObjectInputStream = new ObjectInputStream(skillBufferedInputStream);
			ServerConstant.skillList = (CopyOnWriteArrayList<Skill>) skillObjectInputStream.readObject();
			skillObjectInputStream.close();
			logger.log(Level.FINEST, "skill data loaded successfully.");

			logger.log(Level.FINEST, "loding the role data into the system.");

			BufferedInputStream roleInputStream = new BufferedInputStream(
					cld.getResourceAsStream(ServerConstant.ROLE_DATA_FILE));

			BufferedInputStream roleBufferedInputStream = new BufferedInputStream(roleInputStream);
			ObjectInputStream roleObjectInputStream = new ObjectInputStream(roleBufferedInputStream);
			ServerConstant.roles = (CopyOnWriteArrayList<Role>) roleObjectInputStream.readObject();
			roleObjectInputStream.close();
			logger.log(Level.FINEST, "role data loaded successfully.");

			// FileInputStream stageInputStream = new
			// FileInputStream("src//resources//stage.ser");
			logger.log(Level.FINEST, "loding the stage data into the system.");

			BufferedInputStream stageInputStream = new BufferedInputStream(
					cld.getResourceAsStream(ServerConstant.STAGE_DATA_FILE));

			BufferedInputStream stageBufferedInputStream = new BufferedInputStream(stageInputStream);
			ObjectInputStream stageObjectInputStream = new ObjectInputStream(stageBufferedInputStream);
			ServerConstant.stages = (CopyOnWriteArrayList<Stage>) stageObjectInputStream.readObject();
			stageObjectInputStream.close();
			logger.log(Level.FINEST, "stage data loaded successfully.");

			logger.log(Level.FINEST, "quiz data loaded successfully.");

			BufferedInputStream quizInputStream = new BufferedInputStream(
					cld.getResourceAsStream(ServerConstant.QUIZ_DATA_FILE));

			BufferedInputStream quizBufferedInputStream = new BufferedInputStream(quizInputStream);
			ObjectInputStream quizObjectInputStream = new ObjectInputStream(quizBufferedInputStream);
			ServerConstant.quiz = (CopyOnWriteArrayList<Quiz>) quizObjectInputStream.readObject();
			quizObjectInputStream.close();
			logger.log(Level.FINEST, "quiz data loaded successfully.");

			// FileInputStream questionInputStream = new
			// FileInputStream("src//resources//question.ser");
			logger.log(Level.FINEST, "loding the question data into the system.");

			BufferedInputStream questionInputStream = new BufferedInputStream(
					cld.getResourceAsStream(ServerConstant.QUESTION_DATA_FILE));

			BufferedInputStream questionBufferedInputStream = new BufferedInputStream(questionInputStream);
			ObjectInputStream questionObjectInputStream = new ObjectInputStream(questionBufferedInputStream);
			ServerConstant.question = (CopyOnWriteArrayList<Question>) questionObjectInputStream.readObject();
			questionObjectInputStream.close();
			logger.log(Level.FINEST, "question data loaded successfully.");

			logger.log(Level.FINEST, "mapping incomming data to the mapping collections.");

			for (User user : ServerConstant.userList) {
				ServerConstant.userMap.put(user.getUserName(), user);
			}

			for (Stage stage : ServerConstant.stages) {
				ServerConstant.stateMap.put(stage.getId(), stage);
			}

			for (Skill skill : ServerConstant.skillList) {
				ServerConstant.skillMap.put(skill.getId(), skill);
			}

			for (Quiz quiz : ServerConstant.quiz) {
				ServerConstant.quizMap.put(quiz.getId(), quiz);
			}

			for (Question question : ServerConstant.question) {
				ServerConstant.questionMap.put(question.getId(), question);
			}
			logger.log(Level.FINEST, "mapping of incomming data is completed successfully.");

		} catch (Exception e) {
			logger.log(Level.SEVERE, "erroe while loading metadata into the system.");

			throw new CustomException("Error while loading the data", 500);

		}
	}

}
