package com.challanger.server.processor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Set;
import java.util.logging.Logger;

import com.challanger.server.constants.MessageConstants;
import com.challanger.server.constants.RoutingMap;
import com.challanger.server.constants.ServerConstant;
import com.challanger.server.dto.ErrorObject;
import com.challanger.server.dto.FunctionalValidator;
import com.challanger.server.stage.factory.StageProcessorFactory;
import com.challanger.server.stub.Messanger;
import com.challanger.server.stub.Skill;
import com.challanger.server.stub.Stage;
import com.challanger.server.validator.FourthStageValidatorServiceImpl;
import com.challanger.server.validator.ValidatorService;

public class FourthStageProcessor implements StageProcessor {

	private String STAGE_ID = "4";

	static Logger logger = Logger.getLogger(FourthStageProcessor.class.getName());

	@Override
	public Object getStageMessage(Messanger messanger) {
		// return the list of opted course with id and name
		String concudingRemarks = null;
		ErrorObject error = null;
		Set<Skill> courses = ServerConstant.userMap.get(messanger.getMetaData().getUserName()).getCourses();

		StringBuffer availableCourses = new StringBuffer();
		availableCourses.append(MessageConstants.AVAILABLE_COURSES_MESSAGE + "\n");
		if (null != courses) {
			for (Skill skill : courses) {
				availableCourses.append("id::" + skill.getId() + " " + "Name ::" + skill.getName() + "\n");
			}
			concudingRemarks = MessageConstants.READ_COURSE_ID;
		} else {
			concudingRemarks = MessageConstants.NO_COURSE_IN_ACCOUNT;
			error = new ErrorObject();
			error.setErrorMessage(concudingRemarks);
			return error;
		}

		return availableCourses + concudingRemarks + "\n";

	}

	@Override
	public Messanger processInput(Messanger messanger) {
		// display the contents of course mapped with id
		ValidatorService validatorService = new FourthStageValidatorServiceImpl();
		Boolean result = validatorService.validate(messanger);
		if (result) {
			FunctionalValidator functionalValidator = validatorService.functionalValidation(messanger);
			if (functionalValidator.getResult()) {
				Skill skill = ServerConstant.skillMap.get(Integer.parseInt(messanger.getMessage()));
				String fileName = skill.getDescFileName();
				try {
					ClassLoader cld = Thread.currentThread().getContextClassLoader();
					fileName = cld.getResource(fileName).getFile();
					System.out.println(fileName);

					File file = null;
					if (fileName.contains("jar")) {
						file = new File(fileName.toString().replace("file:", "").replace("!", "").replace(".jar", "")
								.replace("jar", "").substring(1));
					} else {
						file = new File(fileName);
					}
					FileReader fileReader = new FileReader(file);
					BufferedReader bufferedReader = new BufferedReader(fileReader);
					StringBuffer stringBuffer = new StringBuffer();
					String line;
					while ((line = bufferedReader.readLine()) != null) {
						stringBuffer.append(line);
						stringBuffer.append("\n");
					}
					fileReader.close();
					System.out.println(stringBuffer.toString());
					String message = stringBuffer.toString();
					Integer nextStageId = (Integer) RoutingMap.routingMap.get(STAGE_ID)
							.get(ServerConstant.SUCCESS_FLAG);
					Stage nextStage = ServerConstant.stateMap.get(nextStageId);
					StageProcessor stageProcessor = StageProcessorFactory.getProcessor(nextStageId);
					messanger.setState(nextStage);
					String stageMessage = (String) stageProcessor.getStageMessage(messanger);
					messanger.setMessage(message + "\n" + stageMessage);
				} catch (Exception e) {
					e.printStackTrace();
					// TODO Auto-generated catch block
					messanger.setMessage(ServerConstant.SOMETHING_WRONG + "\n");
				}
			} else {
				String message = functionalValidator.getMessage();
				Integer nextStageId = (Integer) RoutingMap.routingMap.get(STAGE_ID).get(ServerConstant.FAILURE_FLAGE);
				Stage nextStage = ServerConstant.stateMap.get(nextStageId);
				StageProcessor stageProcessor = StageProcessorFactory.getProcessor(nextStageId);
				messanger.setState(nextStage);
				String stageMessage = (String) stageProcessor.getStageMessage(messanger);
				messanger.setMessage(message + "\n" + "\n" + stageMessage);
			}
		} else {
			messanger.setMessage(MessageConstants.VALID_INPUT);
		}
		return messanger;
	}

}
