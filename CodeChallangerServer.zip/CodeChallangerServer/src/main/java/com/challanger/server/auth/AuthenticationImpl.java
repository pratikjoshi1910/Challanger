package com.challanger.server.auth;

import java.util.logging.Level;
import java.util.logging.Logger;

import com.challanger.server.constants.MessageConstants;
import com.challanger.server.constants.ServerConstant;
import com.challanger.server.stage.factory.StageProcessorFactory;
import com.challanger.server.stub.Messanger;
import com.challanger.server.stub.MetaData;
import com.challanger.server.stub.Stage;
import com.challanger.server.stub.User;

public class AuthenticationImpl implements Authntication {

	Logger logger = Logger.getLogger(Authntication.class.getName());

	
	/* (non-Javadoc)
	 * @see com.challanger.server.auth.Authntication#authenticate(java.lang.String)
	 */
	
	//Basic authentication is implemented here how ever we 
	// can plug serveral  other authentication implementation 
	// in parellel to basic by implementing the Authentication 
	// interface..
	@SuppressWarnings("unused")
	@Override
	public Messanger authenticate(String credentials) {
		Messanger messanger = new Messanger();
		String[] credetials = credentials.split(":");
		if (null == credentials) {
			messanger.setMessage(MessageConstants.USER_DOES_NOT_EXIST);
			messanger.setState(ServerConstant.stateMap.get(1));
			messanger.setIsStartUp(true);

		} else {
			String userName = credetials[0];
			String password = credetials[1];
			User user = ServerConstant.userMap.get(userName);
			if (null == user) {
				messanger.setMessage(MessageConstants.USER_DOES_NOT_EXIST);
				messanger.setState(ServerConstant.stateMap.get(1));
				messanger.setIsStartUp(true);
				logger.log(Level.FINE , "no user exist for  username" +userName);

				return messanger;
			}
			if (password.equals(user.getPassword())) {
				Stage stage = user.getCurrentStage();
				if (null != stage) {
					messanger.setState(stage);
					messanger.setMessage(StageProcessorFactory.getProcessor(2).getStageMessage(messanger).toString());
					logger.info("user credentials verified successfully for " +userName);

				} else {
					messanger.setState(ServerConstant.stateMap.get(2));
					user.setCurrentStage(ServerConstant.stateMap.get(2));
					messanger.setMessage(StageProcessorFactory.getProcessor(2).getStageMessage(messanger).toString());
				}
				MetaData metaData = new MetaData();
				metaData.setUserName(userName);
				messanger.setMetaData(metaData);

			} else {
				logger.log(Level.FINE , "user credentials does not match for ::" +userName);

				messanger.setMessage(MessageConstants.WRONG_CREDNTIALS);
				messanger.setState(ServerConstant.stateMap.get(1));
				messanger.setIsStartUp(true);

			}
		}
		return messanger;
	}

}
