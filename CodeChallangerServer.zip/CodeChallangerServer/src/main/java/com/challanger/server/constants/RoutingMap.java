package com.challanger.server.constants;

import java.util.HashMap;
import java.util.Map;

/**
 * @author pratik
 * 
 *this map stores the configuration for the 
 *workflow in order to make it more 
 *configurble we can externalize the same in 
 *caching memory so that workflow can be 
 *changed runtime without downtime.
 */
public class RoutingMap {

	public static Map<String, Map<String, Integer>> routingMap = new HashMap<>();

	// this block loads the workflow data any change in the workflow
	// can be configured from here with corresponding action and next
	// stage mappings.
	static {
		Map<String, Integer> secondStage = new HashMap<>();

		secondStage.put("1", 3);
		secondStage.put("2", 4);
		secondStage.put("3", 5);
		secondStage.put("4", 8);
		
		Map<String, Integer> thirdStage = new HashMap<String, Integer>();
		thirdStage.put("Success", 2);
		Map<String, Integer> fourthStage = new HashMap<String, Integer>();
		fourthStage.put("Success", 2);
		fourthStage.put("Failure", 2);

		Map<String, Integer> fifthStageMap = new HashMap<String, Integer>();
		fifthStageMap.put("Success", 6);
		fifthStageMap.put("Failure", 2);

		Map<String, Integer> sixthStageMap = new HashMap<String, Integer>();
		sixthStageMap.put("Success", 7);
		sixthStageMap.put("Failure", 2);

		Map<String, Integer> seventhStageMap = new HashMap<String, Integer>();
		seventhStageMap.put("Success", 2);
		seventhStageMap.put("Failure", 6);
		
		Map<String, Integer> eigthStageMap = new HashMap<String, Integer>();
		seventhStageMap.put("Success", 2);
		seventhStageMap.put("Failure", 2);

		routingMap.put("2", secondStage);
		routingMap.put("3", thirdStage);
		routingMap.put("4", fourthStage);
		routingMap.put("5", fifthStageMap);
		routingMap.put("6", sixthStageMap);
		routingMap.put("7", seventhStageMap);
		routingMap.put("8", eigthStageMap);

	}

}
