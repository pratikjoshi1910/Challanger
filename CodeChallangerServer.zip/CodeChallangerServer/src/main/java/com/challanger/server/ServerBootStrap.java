package com.challanger.server;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * @author pratik
 *
 *This class work as a entry calss
 *and call the other bootstrap class
 *from the serverTemplate method.
 */
public class ServerBootStrap {

	public static void main(String[] args) {

		Logger logger = Logger.getLogger(ServerBootStrap.class.getName());
		try {
			logger.info("calling the bootstrap class.");
			ServerTemplate.serverStarterTemplate();
		} catch (ClassNotFoundException | NoSuchMethodException | SecurityException | IllegalAccessException
				| IllegalArgumentException | InvocationTargetException | IOException e) {
			logger.log(Level.SEVERE, "Exception occured in the main class " + e.getMessage());
		}

	}

}
