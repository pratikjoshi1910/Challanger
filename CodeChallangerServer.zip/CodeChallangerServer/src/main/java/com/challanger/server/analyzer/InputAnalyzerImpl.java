package com.challanger.server.analyzer;

import com.challanger.server.auth.AuthenticationImpl;
import com.challanger.server.auth.Authntication;
import com.challanger.server.processor.StageProcessor;
import com.challanger.server.stage.factory.StageProcessorFactory;
import com.challanger.server.stub.Command;
import com.challanger.server.stub.Messanger;

/**
 * @author pratik
 *
 *         primary implementation of the inputAnalyzer interface and
 *         evaluatereceived object based on the state associated with it.
 */
public class InputAnalyzerImpl implements InputAnalyzer {

	@Override
	public Messanger analyzeInput(Object receivedMessage) {

		Messanger messanger = new Messanger();
		if (receivedMessage.getClass().equals(Command.class)) {

		} else {
			messanger = (Messanger) receivedMessage;
			Integer id = messanger.getState().getId();
			if (id.equals(1)) {
				// first stage is specifically for authentication purpose
				// so excluded from the stage processor and denoted with
				// authentication.
				Authntication auth = new AuthenticationImpl();
				messanger = auth.authenticate(messanger.getMessage());
			} else {
				// fetch coresponding stage1 processor from the factory method.
				StageProcessor stageProcessor = StageProcessorFactory.getProcessor(id);
				messanger = stageProcessor.processInput(messanger);

			}
		}

		return messanger;
	}

}
