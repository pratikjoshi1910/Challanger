package com.challanger.server.processor;

import java.util.Set;
import java.util.logging.Logger;

import com.challanger.server.constants.MessageConstants;
import com.challanger.server.constants.RoutingMap;
import com.challanger.server.constants.ServerConstant;
import com.challanger.server.dto.ErrorObject;
import com.challanger.server.dto.FunctionalValidator;
import com.challanger.server.stage.factory.StageProcessorFactory;
import com.challanger.server.stub.Messanger;
import com.challanger.server.stub.Skill;
import com.challanger.server.stub.Stage;
import com.challanger.server.validator.FourthStageValidatorServiceImpl;
import com.challanger.server.validator.ValidatorService;

public class FifthStageProcessor implements StageProcessor {

	private String STAGE_ID = "5";

	static Logger logger = Logger.getLogger(FifthStageProcessor.class.getName());

	@Override
	public Object getStageMessage(Messanger messanger) {
		// TODO Auto-generated method stub

		logger.info("fetching fifth stage message for the user" + messanger.getMetaData().getUserName());

		// return the list of opted course with id and name
		String concudingRemarks = null;
		ErrorObject error = null;
		Set<Skill> courses = ServerConstant.userMap.get(messanger.getMetaData().getUserName()).getCourses();

		StringBuffer availableCourses = new StringBuffer();
		availableCourses.append(MessageConstants.AVAILABLE_COURSES_MESSAGE + "\n");
		if (null != courses) {
			for (Skill skill : courses) {
				availableCourses.append("id::" + skill.getId() + " " + "Name ::" + skill.getName() + "\n");
			}
			concudingRemarks = MessageConstants.FIFTH_STAGE_CONCLUDING_REMARK;

		} else {
			concudingRemarks = MessageConstants.NO_COURSE_IN_ACCOUNT;
			error = new ErrorObject();
			error.setErrorMessage(concudingRemarks);
			return error;
		}
		logger.info("fetching fifth stage message for the user" + messanger.getMetaData().getUserName());

		return availableCourses + concudingRemarks + "\n";

	}

	@Override
	public Messanger processInput(Messanger messanger) {
		// display the contents of course mapped with id
		logger.info(
				"processing fifth stage input for " + messanger.getMetaData().getUserName() + messanger.getMessage());

		ValidatorService validatorService = new FourthStageValidatorServiceImpl();
		Boolean result = validatorService.validate(messanger);
		if (result) {
			FunctionalValidator functionalValidator = validatorService.functionalValidation(messanger);
			if (functionalValidator.getResult()) {
				logger.info("processing success message for " + messanger.getMetaData().getUserName()
						+ messanger.getMessage());

				// Skill skill =
				// ServerConstant.skillMap.get(Integer.parseInt(messanger.getMessage()));
				Integer nextStageId = (Integer) RoutingMap.routingMap.get(STAGE_ID).get(ServerConstant.SUCCESS_FLAG);
				Stage nextStage = ServerConstant.stateMap.get(nextStageId);
				StageProcessor stageProcessor = StageProcessorFactory.getProcessor(nextStageId);
				messanger.setState(nextStage);
				String stageMessage = (String) stageProcessor.getStageMessage(messanger);
				messanger.setMessage(stageMessage);
			} else {
				String message = functionalValidator.getMessage();
				Integer nextStageId = (Integer) RoutingMap.routingMap.get(STAGE_ID).get(ServerConstant.FAILURE_FLAGE);
				Stage nextStage = ServerConstant.stateMap.get(nextStageId);
				StageProcessor stageProcessor = StageProcessorFactory.getProcessor(nextStageId);
				messanger.setState(nextStage);
				String stageMessage = (String) stageProcessor.getStageMessage(messanger);
				messanger.setMessage(message + "\n" + "\n" + stageMessage);
				logger.info("processing failure message for " + messanger.getMetaData().getUserName()
						+ messanger.getMessage());

			}
		} else {
			messanger.setMessage(MessageConstants.VALID_INPUT);
			logger.info(
					"processing success message for " + messanger.getMetaData().getUserName() + messanger.getMessage());

		}
		return messanger;
	}

}
