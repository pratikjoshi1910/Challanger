package com.challanger.server.dto;

/**
 * @author pratik
 *
 *         Data object holds the skill and quiz wise progress of the user
 */
public class UserSkillProgress {

	private String userName;

	private Integer skillId;

	private Integer quizId;

	private Integer totalAnswers = 0;

	private Boolean isCompleted = false;

	private Integer correctAnswer = 0;

	private Integer totalWrongAnswer = 0;

	private Long creditEarn = 0l;

	/**
	 * @return the isCompleted
	 */
	public Boolean getIsCompleted() {
		return isCompleted;
	}

	/**
	 * @param isCompleted
	 *            the isCompleted to set
	 */
	public void setIsCompleted(Boolean isCompleted) {
		this.isCompleted = isCompleted;
	}

	/**
	 * @return the correctAnswer
	 */
	public Integer getCorrectAnswer() {
		return correctAnswer;
	}

	/**
	 * @param correctAnswer
	 *            the correctAnswer to set
	 */
	public void setCorrectAnswer(Integer correctAnswer) {
		this.correctAnswer = correctAnswer;
	}

	/**
	 * @return the totalWrongAnswer
	 */
	public Integer getTotalWrongAnswer() {
		return totalWrongAnswer;
	}

	/**
	 * @param totalWrongAnswer
	 *            the totalWrongAnswer to set
	 */
	public void setTotalWrongAnswer(Integer totalWrongAnswer) {
		this.totalWrongAnswer = totalWrongAnswer;
	}

	/**
	 * @return the creditEarn
	 */
	public Long getCreditEarn() {
		return creditEarn;
	}

	/**
	 * @param creditEarn
	 *            the creditEarn to set
	 */
	public void setCreditEarn(Long creditEarn) {
		this.creditEarn = creditEarn;
	}

	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {

		return userName.hashCode();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null) {
			return false;
		}
		if (!(obj instanceof UserSkillProgress)) {
			return false;
		}
		UserSkillProgress other = (UserSkillProgress) obj;
		if (quizId == null) {
			if (other.quizId != null) {
				return false;
			}
		} else if (!quizId.equals(other.quizId)) {
			return false;
		}
		if (skillId == null) {
			if (other.skillId != null) {
				return false;
			}
		} else if (!skillId.equals(other.skillId)) {
			return false;
		}
		if (userName == null) {
			if (other.userName != null) {
				return false;
			}
		} else if (!userName.equals(other.userName)) {
			return false;
		}
		return true;
	}

	/**
	 * @param userName
	 *            the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}

	/**
	 * @return the skillId
	 */
	public Integer getSkillId() {
		return skillId;
	}

	/**
	 * @param skillId
	 *            the skillId to set
	 */
	public void setSkillId(Integer skillId) {
		this.skillId = skillId;
	}

	/**
	 * @return the quizId
	 */
	public Integer getQuizId() {
		return quizId;
	}

	/**
	 * @param quizId
	 *            the quizId to set
	 */
	public void setQuizId(Integer quizId) {
		this.quizId = quizId;
	}

	/**
	 * @return the totalAnswers
	 */
	public Integer getTotalAnswers() {
		return totalAnswers;
	}

	/**
	 * @param totalAnswers
	 *            the totalAnswers to set
	 */
	public void setTotalAnswers(Integer totalAnswers) {
		this.totalAnswers = totalAnswers;
	}

}
