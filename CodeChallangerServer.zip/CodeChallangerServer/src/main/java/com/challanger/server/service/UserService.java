package com.challanger.server.service;

import java.io.IOException;
import java.util.List;
import java.util.Set;

import com.challanger.server.stub.Skill;
import com.challanger.server.stub.User;

/**
 * @author pratik
 *
 *provides user level CRUD operations
 */
/**
 * @author pratik
 *
 */
public interface UserService {
	
	Set<Skill> getUseCourses(String userName); 
	
	List <Skill> getUserAvailableCourses(String userName); 
	
	Long getUserCredit(String userName); 
	
	List<User> getAllUser();
	
	void addSkillToUser(String userName,List<Skill> skills) throws IOException;
	

}
