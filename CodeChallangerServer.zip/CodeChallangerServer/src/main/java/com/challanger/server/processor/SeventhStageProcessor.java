package com.challanger.server.processor;

import com.challanger.server.constants.RoutingMap;
import com.challanger.server.constants.ServerConstant;
import com.challanger.server.stage.factory.StageProcessorFactory;
import com.challanger.server.stub.Messanger;
import com.challanger.server.stub.Stage;

public class SeventhStageProcessor implements StageProcessor{

	@Override
	public Object getStageMessage(Messanger messanger) {
		// TODO Auto-generated method stub
		return "";
	}

	@Override
	public Messanger processInput(Messanger messanger) {
		// TODO Auto-generated method stub
		Integer nextStageId = (Integer) RoutingMap.routingMap.get("7").get("Success");
		Stage nextStage = ServerConstant.stateMap.get(nextStageId);
		StageProcessor stageProcessor = StageProcessorFactory.getProcessor(nextStageId);
		messanger.setState(nextStage);
		String stageMessage = (String) stageProcessor.getStageMessage(messanger);
		messanger.setMessage(stageMessage);
		return messanger;
	}

}
