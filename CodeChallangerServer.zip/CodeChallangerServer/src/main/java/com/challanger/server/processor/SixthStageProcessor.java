package com.challanger.server.processor;

import java.util.HashSet;
import java.util.Set;

import com.challanger.server.constants.RoutingMap;
import com.challanger.server.constants.ServerConstant;
import com.challanger.server.dto.ErrorObject;
import com.challanger.server.dto.FunctionalValidator;
import com.challanger.server.dto.UserSkillProgress;
import com.challanger.server.stage.factory.StageProcessorFactory;
import com.challanger.server.stub.Messanger;
import com.challanger.server.stub.Question;
import com.challanger.server.stub.QuestionPayLoad;
import com.challanger.server.stub.Quiz;
import com.challanger.server.stub.Skill;
import com.challanger.server.stub.Stage;
import com.challanger.server.stub.User;
import com.challanger.server.validator.SixthStageValidatorServiceImpl;
import com.challanger.server.validator.ValidatorService;

public class SixthStageProcessor implements StageProcessor {

	@Override
	public Object getStageMessage(Messanger messanger) {
		// TODO Auto-generated method stub
		// return the list of opted course with id and name
		String concudingRemarks = null;
		ErrorObject error = null;
		Set<Skill> courses = ServerConstant.userMap.get(messanger.getMetaData().getUserName()).getCourses();
		Set<Quiz> quizs = new HashSet<>();
		StringBuffer availableQuizs = new StringBuffer();
		availableQuizs.append("Following are the quizs available for you." + "\n");
		if (null != courses) {
			for (Skill skill : courses) {
				if (null != skill.getQuizs()) {
					quizs.addAll(skill.getQuizs());
				}
			}

			for (Quiz quiz : quizs) {
				availableQuizs.append("id::" + quiz.getId() + " " + "name::" + quiz.getName() + " " + "credits::"
						+ quiz.getCredits() + "\n");
			}
			concudingRemarks = "Please select id of the quiz you want to take a challange.";
		} else {
			concudingRemarks = "You do not have any course please buy it then only you will be able to take a challange.";
			error = new ErrorObject();
			error.setErrorMessage(concudingRemarks);
			return error;
		}

		return availableQuizs + "\n" + concudingRemarks + "\n";
	}

	@Override
	public Messanger processInput(Messanger messanger) {
		ValidatorService validatorService = new SixthStageValidatorServiceImpl();
		Boolean isValid = validatorService.validate(messanger);
		if (null == messanger.getPayLoad()) {
			// display corresponding quizquestion
			if (isValid) {
				FunctionalValidator validator = validatorService.functionalValidation(messanger);
				if (validator.getResult()) {
					messanger = getQuestionPayLoad(messanger, validator);
					return messanger;

				} else {
					setFailureResposne(messanger, validator);
				}

			} else {
				messanger.setMessage("Please enter valid input.");
			}

		} else {
			if (isValid) {
				FunctionalValidator validator = validatorService.functionalValidation(messanger);
				if (validator.getResult()) {
					QuestionPayLoad payload = (QuestionPayLoad) messanger.getPayLoad();
					// verify the answer
					Question question = ServerConstant.questionMap.get(payload.getQuestionId());
					User user = ServerConstant.userMap.get(messanger.getMetaData().getUserName());
					UserSkillProgress userSkillProgress = (UserSkillProgress) validator.getSearchings()
							.get("userSkillProgress");
					Quiz quiz = (Quiz) validator.getSearchings().get("quiz");
					Integer totalAnswer = userSkillProgress.getTotalAnswers() + 1;
					Boolean isCompleted = false;
					userSkillProgress.setTotalAnswers(totalAnswer);
					if (totalAnswer.equals(quiz.getQuestions().size()))
						isCompleted = true;
					if (payload.getAnswer().equals(question.getAnswer())) {

						Long credit = user.getCredits();
						user.setCredits(question.getCredits() + credit);

						userSkillProgress.setCorrectAnswer(userSkillProgress.getCorrectAnswer() + 1);
						userSkillProgress.setCreditEarn(userSkillProgress.getCreditEarn() + credit);
					} else {
						userSkillProgress.setTotalWrongAnswer(userSkillProgress.getTotalWrongAnswer() + 1);

					}
					if (!isCompleted) {
						messanger = getQuestionPayLoad(messanger, validator);
					}
					else
					{
						userSkillProgress.setIsCompleted(true);
						Integer nextStageId = (Integer) RoutingMap.routingMap.get("6").get("Success");
						Stage nextStage = ServerConstant.stateMap.get(nextStageId);
						StageProcessor stageProcessor = StageProcessorFactory.getProcessor(nextStageId);
						messanger.setState(nextStage);
						String stageMessage = (String) stageProcessor.getStageMessage(messanger);
						String concludingMessage = "You have successfully completed quiz.";
						messanger.setPayLoad(null);
						messanger.setMessage(concludingMessage +stageMessage);
					}

				} else {
					setFailureResposne(messanger, validator);

				}
			} else {
				messanger.setMessage("Please enter valid input.");
			}

		}
		return messanger;
	}

	private Messanger setFailureResposne(Messanger messanger, FunctionalValidator validator) {
		String message = validator.getMessage();
		Integer nextStageId = (Integer) RoutingMap.routingMap.get("6").get("Failure");
		Stage nextStage = ServerConstant.stateMap.get(nextStageId);
		StageProcessor stageProcessor = StageProcessorFactory.getProcessor(nextStageId);
		messanger.setState(nextStage);
		String stageMessage = (String) stageProcessor.getStageMessage(messanger);
		messanger.setMessage(message + "\n" + "\n" + stageMessage);
		return messanger;
	}

	private Messanger getQuestionPayLoad(Messanger messanger, FunctionalValidator validator) {

		Quiz quiz = (Quiz) validator.getSearchings().get("quiz");
		UserSkillProgress userSkillProgress = (UserSkillProgress) validator.getSearchings().get("userSkillProgress");
		Integer currentQuestionIndex = userSkillProgress.getTotalAnswers();

		Question question = quiz.getQuestions().get(currentQuestionIndex);
		String questionString = question.getQuestion();
		String optionString = String.join("\n", question.getOptions());
		Integer id = question.getId();
		QuestionPayLoad questionPayLoad = new QuestionPayLoad();
		questionPayLoad.setOptions(optionString);
		questionPayLoad.setQuestionId(id);
		questionPayLoad.setQuestion(questionString);
		messanger.setPayLoad(questionPayLoad);
		return messanger;
	}
}
