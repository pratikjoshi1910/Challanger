package com.challanger.server.constants;

/**
 * @author pratik
 *
 */
public class MessageConstants {
	
	public static final String LOGIN_MESSAGE = "Please enter your username:password";
	
	public static final String CLIENT_CONNECTION_DROP  = "Connection dropped for the client  ";

	public static final String USER_DOES_NOT_EXIST = "User Does not exist in system please contact admin.";

	public static String WRONG_CREDNTIALS = "either  username or password is wrong please verify the credentials.";

	public static String SECOND_STAGE_WELCOME_MESSAGE = "Welcome to the challanger please select your options"+ "\n"
			+ "1) Buy new skills." + "\n"
			+ "2) Read a course" + "\n"
			+ "3) Take a challaenge" + "\n"
			+ "4)  know your credits" + "\n";
	public static String COURSE_SUCCESS_MESSAGE = "Course Has been purchased successfully.    " ; 
	
	public static String AVAILABLE_COURSES_MESSAGE = "Your available courses are given below.";
	
	public static String FIFTH_STAGE_CONCLUDING_REMARK = "Please select id of the course you want to take a challange.";
	
	public static String NO_COURSE_IN_ACCOUNT = "You do not have any course please buy it then only you will be able to take a challange.";
	
	public static String VALID_INPUT = "Please enter valid input.";
	
	public static String READ_COURSE_ID= "Please select id of the course you want to read.";

}
