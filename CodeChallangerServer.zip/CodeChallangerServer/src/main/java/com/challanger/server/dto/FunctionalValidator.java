package com.challanger.server.dto;

import java.util.HashMap;
import java.util.Map;

/**
 * @author pratik
 *
 *         central component for functional validation of the payload at
 *         different stage of workflow in the system.
 */
public class FunctionalValidator {

	public Boolean result;

	public String message;

	public Map<String, Object> searchings = new HashMap<>();

	/**
	 * @return the result
	 */
	public Boolean getResult() {
		return result;
	}

	/**
	 * @return the searchings
	 */
	public Map<String, Object> getSearchings() {
		return searchings;
	}

	/**
	 * @param searchings
	 *            the searchings to set
	 */
	public void setSearchings(Map<String, Object> searchings) {
		this.searchings = searchings;
	}

	/**
	 * @param result
	 *            the result to set
	 */
	public void setResult(Boolean result) {
		this.result = result;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message
	 *            the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

}
