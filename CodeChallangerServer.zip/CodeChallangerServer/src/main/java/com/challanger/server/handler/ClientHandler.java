package com.challanger.server.handler;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Observable;
import java.util.Observer;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.challanger.server.ServerBootStrap;
import com.challanger.server.analyzer.InputAnalyzer;
import com.challanger.server.analyzer.InputAnalyzerImpl;
import com.challanger.server.constants.ServerConstant;
import com.challanger.server.stub.Messanger;
import com.challanger.server.stub.Stage;

/**
 * @author pratik
 *
 *         centralized component for incoming request this thread will maintain
 *         separate communication between server and user.
 */
public class ClientHandler extends Thread implements Observer {

	Logger logger = Logger.getLogger(ServerBootStrap.class.getName());

	private DataInputStream dis;
	private DataOutputStream dos;
	private Socket s;
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	private String userName;
	private Stage state;
	public Boolean connection = true;

	// Constructor
	public ClientHandler(Socket s, DataInputStream dis, DataOutputStream dos) throws IOException {
		this.s = s;
		this.dis = dis;
		this.dos = dos;
		this.oos = new ObjectOutputStream(s.getOutputStream());
		this.ois = new ObjectInputStream(s.getInputStream());

	}

	public void otherMessage(String message) throws IOException {
		dos.writeUTF(message);
	}

	@Override
	public void run() {
		Messanger messanger = new Messanger(ServerConstant.stateMap.get(ServerConstant.STAGE_ONE_ID).getMessage());
		logger.info("Message received in client handler run method" + messanger.getMessage());
		try {
			messanger.setIsStartUp(true);
			oos.writeObject(messanger);
			this.state = ServerConstant.stateMap.get(ServerConstant.STAGE_ONE_ID);

		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		while (connection) {
			try {
				Object receivedMessanger = ois.readObject();
				// System.out.println(receivedMessanger);
				if (receivedMessanger instanceof Messanger) {
					messanger = (Messanger) receivedMessanger;
					messanger.setState(this.state);
					InputAnalyzer inputAnalyzer = new InputAnalyzerImpl();
					logger.log(Level.FINEST, "Request assigned to analyzer" + messanger.getMessage());

					Messanger sendData = inputAnalyzer.analyzeInput(receivedMessanger);
					if (null != sendData.getMetaData()) {
						this.userName = sendData.getMetaData().getUserName();
					}
					this.state = sendData.getState();

					oos.writeObject(sendData);
					if (messanger.getMessage().equals("Exit")) {
						System.out.println("Client " + this.s + " sends exit...");
						System.out.println("Closing this connection.");
						this.s.close();
						System.out.println("Connection closed");
						break;
					}
				}
			} catch (IOException | ClassNotFoundException e) {
				try {
					logger.log(Level.SEVERE, "Exception in client handler run method" + e.getMessage());

					this.dis.close();
				} catch (IOException e2) {
					logger.log(Level.SEVERE, "Exception in client handler run method" + e2.getMessage());

					e2.printStackTrace();
				}
				try {
					this.dos.close();
				} catch (IOException e1) {
					logger.log(Level.SEVERE, "Exception in client handler run method" + e1.getMessage());

					e1.printStackTrace();
				}

				try {
					s.close();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				this.connection = false;
			}
		}

		try {
			// closing resources
			this.dis.close();
			this.dos.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@Override
	public void update(Observable o, Object arg) {
		try {
			dos.writeUTF("message from observer.");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
