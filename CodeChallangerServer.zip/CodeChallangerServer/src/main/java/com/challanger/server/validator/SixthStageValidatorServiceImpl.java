package com.challanger.server.validator;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.challanger.server.constants.ServerConstant;
import com.challanger.server.dto.FunctionalValidator;
import com.challanger.server.dto.UserSkillProgress;
import com.challanger.server.stub.Messanger;
import com.challanger.server.stub.Quiz;

public class SixthStageValidatorServiceImpl implements ValidatorService {

	@Override
	public Boolean validate(Messanger messanger) {
		String message = messanger.getMessage();
		if (null == message) {
			return false;

		}

		if (message.isEmpty()) {
			return false;
		} else {
			try {
				Integer.parseInt(message);
				return true;
			} catch (NumberFormatException e) {

			}
		}
		return false;
	}

	@Override
	public FunctionalValidator functionalValidation(Messanger messanger) {
		// TODO Auto-generated method stub
		FunctionalValidator validator = new FunctionalValidator();
		validator.setResult(true);
		String message = messanger.getMessage();
		String userName = messanger.getMetaData().getUserName();
		Quiz quiz = ServerConstant.quizMap.get(Integer.parseInt(message));
		if (null == quiz) {
			validator.setResult(false);
			validator.setMessage("Please enter valid input.");
			return validator;
		}
		validator.searchings.put("quiz", quiz);
		List<UserSkillProgress> userSkillSet = ServerConstant.userSkillMap.get(userName);
		if (null != userSkillSet) {
			List<UserSkillProgress> userSkillList = userSkillSet.stream()
					.filter(x -> x.getQuizId().equals(Integer.parseInt(message))).collect(Collectors.toList());
			if (null != userSkillList) {
				// as it will be only one entry against the quiz for a user
				UserSkillProgress userSkillProgress = userSkillList.get(0);
				boolean isCompleted = userSkillProgress.getIsCompleted();
				if (isCompleted) {
					validator.setResult(false);
					validator.setMessage("Quiz is already completed.");
				} else {
					validator.getSearchings().put("userSkillProgress", userSkillProgress);
				}
			} else {
				validator.getSearchings().put("userSkillProgress", new UserSkillProgress());
			}
		} else {
			UserSkillProgress userSkillProgress = new UserSkillProgress();
			userSkillProgress.setSkillId(quiz.getSkillId());
			userSkillProgress.setQuizId(quiz.getId());
			userSkillProgress.setTotalAnswers(0);
			userSkillProgress.setIsCompleted(false);
			userSkillProgress.setUserName(userName);
			List<UserSkillProgress> userSkillProgressList = new ArrayList<UserSkillProgress>();
			userSkillProgressList.add(userSkillProgress);
			ServerConstant.userSkillMap.put(userName, userSkillProgressList);
			validator.getSearchings().put("userSkillProgress", userSkillProgress);

		}
		return validator;
	}

}
