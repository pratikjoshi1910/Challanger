package com.challanger.server.dto;

/**
 * @author pratik
 *Application error object
 */
public class ErrorObject {
	
	private String errorMessage;

	/**
	 * @return the errorMessage
	 */
	public String getErrorMessage() {
		return errorMessage;
	}

	/**
	 * @param errorMessage the errorMessage to set
	 */
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	} 
	
	
	
	

}
