package com.challanger.server.service;

import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;
import java.util.stream.Collectors;

import com.challanger.server.constants.ServerConstant;
import com.challanger.server.processor.FourthStageProcessor;
import com.challanger.server.stub.Skill;
import com.challanger.server.stub.User;

/**
 * @author pratik
 *
 *         provides user level operations
 */
public class UserServiceImpl implements UserService {
	static Logger logger = Logger.getLogger(UserServiceImpl.class.getName());

	@Override
	public Set<Skill> getUseCourses(String userName) {
		logger.info("calling getUserCourses method  for ::   " + userName);
		return ServerConstant.userMap.get(userName).getCourses();

	}

	@Override
	public List<Skill> getUserAvailableCourses(String userName) {

		logger.info("calling getUserAvailableCourses method  for ::   " + userName);

		Set<Skill> courses = getUseCourses(userName);
		if (null != courses) {
			List<Integer> ids = getUseCourses(userName).stream().map(x -> x.getId()).collect(Collectors.toList());
			CourseService courseService = new CourseServiceImpl();
			return courseService.getAllCourses().stream().filter(x -> !ids.contains(x.getId()))
					.collect(Collectors.toList());
		} else {
			CourseService courseService = new CourseServiceImpl();
			return courseService.getAllCourses();
		}
	}

	@Override
	public Long getUserCredit(String userName) {
		// TODO Auto-generated method stub
		logger.info("calling getUserCredit method  for ::   " + userName);

		return ServerConstant.userMap.get(userName).getCredits();
	}

	@Override
	public List<User> getAllUser() {
		// TODO Auto-generated method stub
		logger.info("calling getAllUser method ");

		return (List<User>) ServerConstant.userMap.values();
	}

	@Override
	public void addSkillToUser(String userName, List<Skill> skills) throws IOException {
		// TODO Auto-generated method stub
		logger.info("calling getAllUser method  for ::" + userName);

		User user = ServerConstant.userMap.get(userName);
		Set<Skill> courses = user.getCourses();
		if (null != courses && courses.size() > 0) {
			courses.addAll(skills);
			user.setCourses(courses);
		} else {
			user.setCourses(new HashSet<Skill>(skills));
		}
		ServerConstant.userMap.put(userName, user);
		/*
		 * FileOutputStream f = new FileOutputStream(new File("role.ser"));
		 * ObjectOutputStream o = new ObjectOutputStream(f); f = new
		 * FileOutputStream(new File("user.ser")); o = new
		 * ObjectOutputStream(f); o.writeObject(ServerConstant.userList);
		 */
	}

}
