package com.challanger.server.stage.factory;

import com.challanger.server.processor.EightStageProcessor;
import com.challanger.server.processor.FifthStageProcessor;
import com.challanger.server.processor.FourthStageProcessor;
import com.challanger.server.processor.SecondStageProcessor;
import com.challanger.server.processor.SeventhStageProcessor;
import com.challanger.server.processor.SixthStageProcessor;
import com.challanger.server.processor.StageProcessor;
import com.challanger.server.processor.ThirdStageProcessor;

/**
 * @author pratik
 *
 *         factory method provides the object of diffrent processor based on
 *         need on paritcular action on workflow
 */
public class StageProcessorFactory {

	public static StageProcessor getProcessor(Integer stageId) {
		switch (stageId) {
		case 2:
			return new SecondStageProcessor();
		case 3:
			return new ThirdStageProcessor();
		case 4:
			return new FourthStageProcessor();
		case 5:
			return new FifthStageProcessor();
		case 6:
			return new SixthStageProcessor();
		case 7:
			return new SeventhStageProcessor();
		case 8:
			return new EightStageProcessor();
		default:
			return new SecondStageProcessor();
		}

	}

}
