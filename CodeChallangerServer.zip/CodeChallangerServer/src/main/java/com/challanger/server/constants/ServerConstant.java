package com.challanger.server.constants;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

import com.challanger.server.dto.UserSkillProgress;
import com.challanger.server.stub.Question;
import com.challanger.server.stub.Quiz;
import com.challanger.server.stub.Role;
import com.challanger.server.stub.Skill;
import com.challanger.server.stub.Stage;
import com.challanger.server.stub.User;

/**
 * @author pratik
 *
 *         class keep the detail of server level constants
 */
public class ServerConstant {

	public static final Object FAILURE_FLAGE = "Failure";

	public static Long MINIMUM_COURSE_PRICE = 1500l;

	public static String CONFIG_PCKG = "com.challanger.server.config";

	public static String CONFIG_ANNOTATION = "com.challanger.server.annotation.Config";

	public static CopyOnWriteArrayList<User> userList;

	public static CopyOnWriteArrayList<Skill> skillList;

	public static CopyOnWriteArrayList<Role> roles;

	public static CopyOnWriteArrayList<Stage> stages;

	public static CopyOnWriteArrayList<Quiz> quiz;

	public static CopyOnWriteArrayList<Question> question;

	public static ConcurrentHashMap<String, User> userMap = new ConcurrentHashMap<String, User>();

	public static ConcurrentHashMap<Integer, Stage> stateMap = new ConcurrentHashMap<Integer, Stage>();

	public static ConcurrentHashMap<User, Stage> userStateMap = new ConcurrentHashMap<User, Stage>();

	public static ConcurrentHashMap<Integer, Skill> skillMap = new ConcurrentHashMap<Integer, Skill>();

	public static ConcurrentHashMap<Integer, Quiz> quizMap = new ConcurrentHashMap<Integer, Quiz>();

	public static CopyOnWriteArrayList<UserSkillProgress> userSkillList = new CopyOnWriteArrayList<>();

	public static ConcurrentHashMap<String, List<UserSkillProgress>> userSkillMap = new ConcurrentHashMap<>();

	public static ConcurrentHashMap<Integer, Question> questionMap = new ConcurrentHashMap<>();

	public static String USER_DATA_FILE = "user.ser";

	public static String ROLE_DATA_FILE = "role.ser";

	public static String SKILL_DATA_FILE = "skill.ser";

	public static String QUIZ_DATA_FILE = "quiz.ser";

	public static String QUESTION_DATA_FILE = "question.ser";

	public static String STAGE_DATA_FILE = "stage.ser";

	public static Integer STAGE_ONE_ID = 1;

	public static Integer STAGE_TWO_ID = 2;

	public static Integer STAGE_THREE_ID = 3;

	public static Integer STAGE_FOUR_ID = 4;

	public static Integer STAGE_FIVE_ID = 5;

	public static Integer STAGE_SIX_ID = 6;

	public static Integer STAGE_SEVEN_ID = 7;

	public static Integer STAGE_EIGNT_ID = 8;
	
	public static String CREDIT_SCORE_PREFIX = "Your credit score is ::  ";
	
	public static String SUCCESS_FLAG  = "Success";
	
	public static String SOMETHING_WRONG= "Something wrong happen on backend please contact admin";

}
