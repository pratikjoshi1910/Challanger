package com.challanger.server.metadatapreparator;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Base64;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import com.challanger.server.stub.Question;
import com.challanger.server.stub.Quiz;
import com.challanger.server.stub.Role;
import com.challanger.server.stub.Skill;
import com.challanger.server.stub.Stage;
import com.challanger.server.stub.User;

public class UserObject {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
try
{
		List<Role> roles = new CopyOnWriteArrayList<Role>();
		Role admin = new Role();
		admin.setId(1);
		admin.setName("admin");
		Role user = new Role();
		user.setName("pratik");
		user.setId(2);
		roles.add(admin);
		roles.add(user);
		FileOutputStream f = new FileOutputStream(new File("src//resources//role.ser"));
		ObjectOutputStream o = new ObjectOutputStream(f);

		// Write objects to file
		o.writeObject(roles);

		// load the questions
		Question question1 = new Question();
		question1.setId(1);
		question1.setQuestion("what is java?");
		LinkedList<String> options1 = new LinkedList<String>();
		options1.add("1) Software language");
		options1.add("2) Software programme");
		options1.add("3) Coffee");
		options1.add("4) Machine");
		question1.setOptions(options1);
		question1.setCredits(700);
		question1.setAnswer(1);

		Question question2 = new Question();
		question2.setId(2);
		question2.setQuestion("what is jvm?");
		question2.setCredits(700);

		LinkedList<String> options2 = new LinkedList<String>();
		options2.add("1) Java Virtual Machine");
		options2.add("2) Software programme");
		options2.add("3) Coffee");
		options2.add("4) Machine");
		question2.setOptions(options2);
		question2.setAnswer(1);

		Question question3 = new Question();
		question3.setId(3);
		question3.setQuestion("what is Object?");
		question3.setCredits(600);

		LinkedList<String> options3 = new LinkedList<String>();
		options3.add("1) Basic Unit of java language");
		options3.add("2) Software programme");
		options3.add("3) Coffee");
		options3.add("4) Machine");
		question3.setOptions(options3);
		question3.setAnswer(1);

		// load the quizs
		CopyOnWriteArrayList<Question> javaQuestionList = new CopyOnWriteArrayList<>();
		javaQuestionList.add(question3);
		javaQuestionList.add(question1);
		javaQuestionList.add(question2);

		f = new FileOutputStream(new File("src//resources//question.ser"));
		o = new ObjectOutputStream(f);
		o.writeObject(javaQuestionList);

		Quiz javaQuiz = new Quiz();
		javaQuiz.setId(1);
		javaQuiz.setQuestions(javaQuestionList);
		javaQuiz.setName("Java Quiz");
		javaQuiz.setCredits(2000);
		javaQuiz.setSkillId(1);

		List<Quiz> javaQuizs = new CopyOnWriteArrayList<>();
		javaQuizs.add(javaQuiz);

		f = new FileOutputStream(new File("src//resources//quiz.ser"));
		o = new ObjectOutputStream(f);
		o.writeObject(javaQuizs);

		//

		List<Skill> skills = new CopyOnWriteArrayList<Skill>();

		Skill java = new Skill();
		Skill php = new Skill();
		Skill cSharp = new Skill();
		Skill python = new Skill();

		java.setName("java");
		java.setId(1);
		java.setPrice(1500);
		java.setDescFileName("Java.txt");
		java.setQuizs(javaQuizs);

		php.setId(2);
		php.setName("php");
		php.setPrice(1500);
		php.setDescFileName("php.txt");
		cSharp.setId(3);
		cSharp.setName("CSharp");
		cSharp.setPrice(1500);
		cSharp.setDescFileName("Csharp.txt");

		python.setName("python");
		python.setId(4);
		python.setPrice(1500);
		python.setDescFileName("python.txt");

		skills.add(java);
		skills.add(php);
		skills.add(cSharp);
		skills.add(python);

		FileOutputStream SkillStream = new FileOutputStream(new File("src//resources//skill.ser"));
		o = new ObjectOutputStream(SkillStream);

		o.writeObject(skills);

		List<Stage> stages = new CopyOnWriteArrayList<>();
		Stage first = new Stage();
		first.setId(1);
		first.setName("Login stage");
		first.setMessage("Please enter your username:password");

		Stage second = new Stage();
		second.setId(2);
		second.setMessage("Welcome to the code challanger please select your options \n" + "1) Buy new skills \n"
				+ "2) Take a new challange \n" + "3) know your credits \n" + "4) Know the top scorers \n");
		second.setName("Menu stage");

		Stage third = new Stage();
		third.setId(3);
		third.setName("Show Skill");
		third.setMessage("Please Select the course from follwoing list.");

		Stage fourth = new Stage();
		fourth.setId(4);
		fourth.setName("Take Challange");
		fourth.setMessage("Following are the challanges available to you.");

		Stage fifth = new Stage();
		fifth.setId(5);
		fifth.setName("Know your Credits");
		fifth.setMessage("your credit score is:: ");

		Stage sixth = new Stage();
		sixth.setId(6);
		sixth.setName("Create Course");
		sixth.setMessage("Welcome to the course creation wizard:: ");

		Stage seven = new Stage();
		seven.setId(7);
		seven.setName("Read Inbox");
		seven.setMessage("Entering in your inbox.");
		
		Stage eight = new Stage();
		eight.setId(8);
		eight.setName("Get your credits");
		eight.setMessage("Entering in your inbox.");

		stages.add(first);
		stages.add(second);
		stages.add(third);
		stages.add(fourth);
		stages.add(fifth);
		stages.add(sixth);
		stages.add(eight);
		stages.add(eight);
		f = new FileOutputStream(new File("src//resources//stage.ser"));
		o = new ObjectOutputStream(f);
		o.writeObject(stages);

		List<User> users = new CopyOnWriteArrayList<User>();
		User player = new User();
		player.setUserName("pratik");
		player.setPassword(Base64.getEncoder().encodeToString("password".getBytes()));
		player.setRole(user);
		player.setCredits(5000l);
		
		User mohit = new User();
		mohit.setUserName("mohit");
		mohit.setPassword(Base64.getEncoder().encodeToString("password".getBytes()));
		mohit.setRole(user);
		mohit.setCredits(5000l);

		User adminUser = new User();
		adminUser.setUserName("admin");
		adminUser.setPassword(Base64.getEncoder().encodeToString("password".getBytes()));
		adminUser.setRole(user);
	    adminUser.setCredits(5000l);

		users.add(player);
		users.add(adminUser);

		f = new FileOutputStream(new File("src//resources//user.ser"));
		o = new ObjectOutputStream(f);
		o.writeObject(users);
}
 catch (Exception e)
{
	 e.printStackTrace();
}
	}

}
