package com.challanger.server.test;

import java.util.Base64;
import java.util.concurrent.ConcurrentHashMap;

import com.challanger.server.auth.AuthenticationImpl;
import com.challanger.server.constants.ServerConstant;

import com.challanger.server.stub.Messanger;
import com.challanger.server.stub.User;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class verifyLoginNegative extends TestCase {
	/**
	 * Create the test case
	 *
	 * @param testName
	 *            name of the test case
	 */
	public verifyLoginNegative(String testName) {
		super(testName);
	}

	/**
	 * @return the suite of tests being tested
	 */
	public static Test suite() {
		return new TestSuite(verifyLoginNegative.class);
	}

	/**
	 * Rigourous Test :-)
	 */
	public void testApp() {
		
		ServerConstant.userMap = new ConcurrentHashMap<>();
		ServerConstant.userMap.put("pratik", new User());
		AuthenticationImpl auth = new AuthenticationImpl();
		Messanger messanger = auth.authenticate("pratik:password");
		assertEquals("either  username or password is wrong please verify the credentials.", messanger.getMessage());

	}
  
	public void verifyLoginNegative()
	{
		ServerConstant.userMap = new ConcurrentHashMap<>();
		ServerConstant.userMap.put("pratik", new User());
		AuthenticationImpl auth = new AuthenticationImpl();
		Messanger messanger = auth.authenticate("pratik:password");
		assertEquals("either  username or password is wrong please verify the credentials.", messanger.getMessage());
	}
	
	public void verifyLoginPositive()
	{
		ServerConstant.userMap = new ConcurrentHashMap<>();
		User user = new User();
		String password = Base64.getEncoder().encodeToString("password".getBytes());
		user.setPassword(password);
		ServerConstant.userMap.put("pratik", user);
		AuthenticationImpl auth = new AuthenticationImpl();
		Messanger messanger = auth.authenticate("pratik:"+password);
		assertEquals("either  username or password is wrong please verify the credentials.", messanger.getMessage());
	}
}
