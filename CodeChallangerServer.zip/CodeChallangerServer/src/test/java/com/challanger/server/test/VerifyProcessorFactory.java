package com.challanger.server.test;

import com.challanger.server.processor.EightStageProcessor;
import com.challanger.server.processor.FifthStageProcessor;
import com.challanger.server.processor.FourthStageProcessor;
import com.challanger.server.processor.SecondStageProcessor;
import com.challanger.server.processor.SeventhStageProcessor;
import com.challanger.server.processor.SixthStageProcessor;
import com.challanger.server.processor.StageProcessor;
import com.challanger.server.processor.ThirdStageProcessor;
import com.challanger.server.stage.factory.StageProcessorFactory;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class VerifyProcessorFactory extends TestCase {
	/**
	 * Create the test case
	 *
	 * @param testName
	 *            name of the test case
	 */
	public VerifyProcessorFactory(String testName) {
		super(testName);
	}

	/**
	 * @return the suite of tests being tested
	 */
	public static Test suite() {
		return new TestSuite(VerifyProcessorFactory.class);
	}

	/**
	 * Rigourous Test :-)
	 */
	public void testApp() {
		StageProcessorFactory stageProcessorFactory = new StageProcessorFactory();
		StageProcessor stageObject = StageProcessorFactory.getProcessor(2);
		assertTrue(stageObject instanceof SecondStageProcessor);
		stageObject = StageProcessorFactory.getProcessor(3);
		assertTrue(stageObject instanceof ThirdStageProcessor);
		stageObject = StageProcessorFactory.getProcessor(4);
		assertTrue(stageObject instanceof FourthStageProcessor);
		stageObject = StageProcessorFactory.getProcessor(5);
		assertTrue(stageObject instanceof FifthStageProcessor);
		stageObject = StageProcessorFactory.getProcessor(6);
		assertTrue(stageObject instanceof SixthStageProcessor);
		stageObject = StageProcessorFactory.getProcessor(7);
		assertTrue(stageObject instanceof SeventhStageProcessor);
		stageObject = StageProcessorFactory.getProcessor(8);
		assertTrue(stageObject instanceof EightStageProcessor);
	}
}
